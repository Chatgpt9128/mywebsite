import React, { useState } from 'react';
import { StarIcon, ShoppingCartIcon } from '@heroicons/react/24/solid';

function App() {
  const [quantity, setQuantity] = useState(1);

  const product = {
    name: 'Makhana Herbed Italian',
    price: 149,
    originalPrice: 199,
    description: 'Indulge in the perfect blend of Italian herbs and spices with our Herbed Italian Makhana. Each pop is carefully seasoned to deliver an authentic taste of Italy.',
    benefits: [
      'High in protein and fiber',
      'Gluten-free snack',
      'No artificial flavors',
      'Rich in antioxidants'
    ],
    rating: 4.5,
    reviews: 128,
    image: 'https://placehold.co/600x400/png'
  };

  const handleQuantityChange = (newQuantity) => {
    if (newQuantity >= 1) {
      setQuantity(newQuantity);
    }
  };

  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="lg:grid lg:grid-cols-2 lg:gap-x-8">
          {/* Product Image */}
          <div className="mb-8 lg:mb-0">
            <img
              src={product.image}
              alt={product.name}
              className="w-full rounded-lg shadow-lg"
            />
          </div>

          {/* Product Details */}
          <div className="lg:pl-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              {product.name}
            </h1>

            <div className="flex items-center mb-4">
              <div className="flex items-center">
                {[...Array(5)].map((_, index) => (
                  <StarIcon
                    key={index}
                    className={`h-5 w-5 ${
                      index < Math.floor(product.rating)
                        ? 'text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="ml-2 text-gray-600">
                ({product.reviews} reviews)
              </span>
            </div>

            <div className="mb-6">
              <span className="text-3xl font-bold text-gray-900">
                ₹{product.price}
              </span>
              <span className="ml-2 text-lg text-gray-500 line-through">
                ₹{product.originalPrice}
              </span>
              <span className="ml-2 text-green-600 font-semibold">
                {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
              </span>
            </div>

            <p className="text-gray-600 mb-6">
              {product.description}
            </p>

            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Benefits:</h3>
              <ul className="list-disc list-inside space-y-2">
                {product.benefits.map((benefit, index) => (
                  <li key={index} className="text-gray-600">
                    {benefit}
                  </li>
                ))}
              </ul>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Quantity
              </label>
              <div className="flex items-center">
                <button
                  onClick={() => handleQuantityChange(quantity - 1)}
                  className="px-3 py-1 border rounded-l bg-gray-100"
                >
                  -
                </button>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => handleQuantityChange(parseInt(e.target.value))}
                  className="w-16 text-center border-t border-b"
                />
                <button
                  onClick={() => handleQuantityChange(quantity + 1)}
                  className="px-3 py-1 border rounded-r bg-gray-100"
                >
                  +
                </button>
              </div>
            </div>

            <button className="w-full bg-green-600 text-white py-3 px-6 rounded-lg flex items-center justify-center space-x-2 hover:bg-green-700 transition duration-200">
              <ShoppingCartIcon className="h-5 w-5" />
              <span>Add to Cart</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;